package cresla.entities.modules;

import cresla.interfaces.AbsorbingModule;

public class HeatProcessor extends BaseAbsorbeModule {

    public HeatProcessor(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}


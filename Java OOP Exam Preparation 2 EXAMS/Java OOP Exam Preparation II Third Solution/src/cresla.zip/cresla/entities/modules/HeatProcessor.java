package cresla.entities.modules;

public class HeatProcessor extends BaseAbsorberMOdule {

    public HeatProcessor(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}

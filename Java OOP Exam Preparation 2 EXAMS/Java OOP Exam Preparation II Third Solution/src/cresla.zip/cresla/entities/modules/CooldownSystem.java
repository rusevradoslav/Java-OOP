package cresla.entities.modules;

public class CooldownSystem extends BaseAbsorberMOdule {

    public CooldownSystem(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}

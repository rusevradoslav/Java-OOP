package cresla.entities.modules;

public class HeatProcessor extends BaseAbsorbeModule {

    public HeatProcessor(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}


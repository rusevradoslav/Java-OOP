package zoo_02;

public class Reptile extends Animal {
    public Reptile(String name) {
        super(name);
    }
}

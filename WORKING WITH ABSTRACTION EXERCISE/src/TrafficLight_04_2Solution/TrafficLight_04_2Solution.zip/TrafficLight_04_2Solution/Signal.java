package TrafficLight_04_2Solution;

public enum Signal {
    RED,
    GREEN,
    YELLOW
}

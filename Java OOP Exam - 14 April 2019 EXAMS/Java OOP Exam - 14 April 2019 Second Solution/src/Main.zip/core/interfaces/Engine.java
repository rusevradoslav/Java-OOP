package core.interfaces;

public class Engine implements Runnable  {
    @Override
    public void run() {

    }
}

import core.ManagerControllerImpl;
import core.interfaces.ManagerController;

public class Main {
    public static void main(String[] args) {

        ManagerController manager = new ManagerControllerImpl();

    }
}

package food_shortage_04;

public interface Person extends Buyer{
    String getName();
    int getAge();
}

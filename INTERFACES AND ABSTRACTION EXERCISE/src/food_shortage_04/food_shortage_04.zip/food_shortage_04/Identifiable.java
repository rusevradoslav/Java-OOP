package food_shortage_04;

public interface Identifiable {
    String getId();

}

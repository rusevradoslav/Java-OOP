package collection_hierarchy_07;

import collection_hierarchy_07.entities.AddCollection;
import collection_hierarchy_07.entities.AddRemoveCollection;
import collection_hierarchy_07.entities.MyListImpl;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<String> line = Arrays.stream(scanner.nextLine().split(" ")).collect(Collectors.toList());
        int numberOfRemoved = Integer.parseInt(scanner.nextLine());
        if (numberOfRemoved > 100) {
            return;
        }

        AddCollection addCollection = new AddCollection();
        AddRemoveCollection addRemoveCollection = new AddRemoveCollection();
        MyListImpl myList = new MyListImpl();

        int[][] output = new int[3][line.size()];
        for (int i = 0; i < line.size(); i++) {
            output[0][i] = addCollection.add(line.get(i));
            output[1][i] = addRemoveCollection.add(line.get(i));
            output[2][i] = myList.add(line.get(i));
        }

        String[][] removedItem = new String[2][numberOfRemoved];
        for (int i = 0; i < numberOfRemoved; i++) {
            removedItem[0][i] = addRemoveCollection.remove();
            removedItem[1][i] = myList.remove();
        }


        for (int i = 0; i < output.length; i++) {
            for (int j = 0; j < output[i].length; j++) {
                System.out.print(output[i][j] + " ");
            }
            System.out.println();
        }

        for (int i = 0; i < removedItem.length; i++) {
            for (int j = 0; j < removedItem[i].length; j++) {
                System.out.print(removedItem[i][j] + " ");
            }
            System.out.println();
        }


    }
}

package collection_hierarchy_07.interfaces;

public interface MyList extends AddRemovable {
    int getUsed();
}

package collection_hierarchy_07.interfaces;

public interface AddRemovable extends Addable {
    String remove();
}

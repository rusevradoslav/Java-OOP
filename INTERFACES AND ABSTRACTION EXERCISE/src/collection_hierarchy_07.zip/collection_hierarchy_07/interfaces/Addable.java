package collection_hierarchy_07.interfaces;

public interface Addable {
    int add(String item);
}

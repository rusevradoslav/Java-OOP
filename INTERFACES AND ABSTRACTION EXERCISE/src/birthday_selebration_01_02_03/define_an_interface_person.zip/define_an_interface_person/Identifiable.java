package define_an_interface_person;

public interface Identifiable {
    String getId();
}

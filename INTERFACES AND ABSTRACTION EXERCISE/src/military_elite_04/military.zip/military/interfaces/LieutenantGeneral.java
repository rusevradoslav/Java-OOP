package military_elite_04.military.interfaces;

public interface LieutenantGeneral extends Private {
    void addPrivate(Private priv);
}

package military_elite_04.military.interfaces;

import military_elite_04.military.enumerations.Corp;

public interface SpecialisedSoldier extends Private {
    String getCorps();
}

package military_elite_04.military.interfaces;

public interface Soldier {
    int getId();

    String getFirstName();

    String getLastName();
}

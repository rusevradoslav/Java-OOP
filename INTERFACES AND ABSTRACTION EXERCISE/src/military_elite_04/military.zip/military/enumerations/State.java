package military_elite_04.military.enumerations;

public enum State {
    inProgress,
    Finished;
}

package military_elite_04.military.entities;

import military_elite_04.military.interfaces.Spy;

public class SpyImpl extends SoldierImpl implements Spy {
    private double codeNumber;

    public SpyImpl(int id, String name, String lastName, double codeNumber) {
        super(id, name, lastName);
        this.codeNumber = codeNumber;
    }

    @Override
    public double getCodeNumber() {
        return this.codeNumber;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());
        sb.append(String.format("Code Number: %.2f", this.getFirstName(), this.getLastName(), this.getId(), this.codeNumber));
        return sb.toString().trim();
    }
}

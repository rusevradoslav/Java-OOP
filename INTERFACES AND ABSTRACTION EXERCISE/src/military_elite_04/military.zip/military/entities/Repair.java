package military_elite_04.military.entities;

public class Repair {
    private System partName;
    private int hoursWorked;

    public Repair(System partName, int hoursWorked) {
        this.partName = partName;
        this.hoursWorked = hoursWorked;
    }

    @Override
    public String toString() {
        return String.format("Part Name: %s Hours Worked: %d", this.partName, this.hoursWorked);
    }
}

package telephony_05;

public interface Callable {
    String call();
}

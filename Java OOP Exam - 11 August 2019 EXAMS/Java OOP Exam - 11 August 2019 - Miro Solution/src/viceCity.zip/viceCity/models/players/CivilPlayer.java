package viceCity.models.players;

public class CivilPlayer extends BasePlayer {
    public CivilPlayer(String name) {
        super(name, 50);
    }
}

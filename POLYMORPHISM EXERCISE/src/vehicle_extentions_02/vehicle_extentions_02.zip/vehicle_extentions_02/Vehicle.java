package vehicle_extentions_02;

public interface Vehicle {
    void drive(double distance);

    void refuel(double liters);

    void driveEmpty(double distance);

}

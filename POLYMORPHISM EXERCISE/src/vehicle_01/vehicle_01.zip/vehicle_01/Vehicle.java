package vehicle_01;

public interface Vehicle {
    void drive(double distance);

    void refuel(double liters);
}

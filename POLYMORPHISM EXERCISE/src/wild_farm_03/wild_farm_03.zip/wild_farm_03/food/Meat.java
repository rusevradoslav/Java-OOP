package wild_farm_03.food;

public class Meat extends Food {
    public Meat(Integer quantity) {
        super(quantity);
    }
}

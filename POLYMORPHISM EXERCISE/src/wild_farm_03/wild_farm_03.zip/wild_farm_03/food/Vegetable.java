package wild_farm_03.food;

public class Vegetable extends Food {

    public Vegetable(Integer quantity) {
        super(quantity);
    }

}

package wild_farm_03.animal;

import wild_farm_03.food.Food;

public interface Animal {

    void makeSound();
    void eat(Food food);

}

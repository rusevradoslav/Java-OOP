package wild_farm_03.animal;

import wild_farm_03.food.Food;

public abstract class Felime extends Mammal {
    protected Felime(String animalType, String animalName, Double animalWeight, String livingRegion) {
        super(animalType, animalName, animalWeight, livingRegion);
    }


}

package car_shop_extend_02;

public interface Rentable extends Car {

    Integer getMinRentDay();

    Double getPricePerDay();

}

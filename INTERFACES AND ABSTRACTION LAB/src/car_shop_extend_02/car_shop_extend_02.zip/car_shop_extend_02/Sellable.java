package car_shop_extend_02;

public interface Sellable extends Car {
    Double getPrice();

}

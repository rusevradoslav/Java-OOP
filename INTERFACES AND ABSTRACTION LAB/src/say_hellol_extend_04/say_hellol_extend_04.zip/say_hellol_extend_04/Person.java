package say_hellol_extend_04;

public interface Person {
    String getName();
    String sayHello();
}

package border_control_05;

public interface Identifiable {
    String getId();
}

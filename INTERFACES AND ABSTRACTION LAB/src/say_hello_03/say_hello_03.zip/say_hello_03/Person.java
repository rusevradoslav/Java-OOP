package say_hello_03;

public interface Person {
    String getName();
    String sayHello();
}

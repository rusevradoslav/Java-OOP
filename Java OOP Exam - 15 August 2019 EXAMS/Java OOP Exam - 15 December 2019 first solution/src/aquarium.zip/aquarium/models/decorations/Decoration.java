package aquarium.models.decorations;

public interface Decoration {
    int getComfort();

    double getPrice();
}

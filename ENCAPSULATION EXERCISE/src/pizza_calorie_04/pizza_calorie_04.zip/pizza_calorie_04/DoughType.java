package pizza_calorie_04;

public enum DoughType {
    Crispy,
    Chewy,
    Homemade,
}

package pizza_calorie_04;

public enum ToppingType {
    Meat,
    Veggies,
    Cheese,
    Sauce,


}

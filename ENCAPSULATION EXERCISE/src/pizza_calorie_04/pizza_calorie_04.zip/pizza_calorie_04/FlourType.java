package pizza_calorie_04;

public enum FlourType {
    White,
    Wholegrain,
}

package football_team_generator_05;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try {


            String[] line = scanner.nextLine().split(";");
            Team team = new Team(line[1]);

            String input = scanner.nextLine();
            while (!input.equals("END")) {
                String[] tokens = input.split(";");
                String command = tokens[0];
                switch (command) {
                    case "Add":
                        if (team.getName().equals(tokens[1])) {
                            try {
                                Player player = new Player(tokens[2], Integer.parseInt(tokens[3]),
                                        Integer.parseInt(tokens[4]),
                                        Integer.parseInt(tokens[5]),
                                        Integer.parseInt(tokens[6]),
                                        Integer.parseInt(tokens[7]));
                                team.addPlayer(player);
                            } catch (Exception e) {
                                System.out.println(e.getMessage());
                            }
                        } else {
                            throw new IllegalArgumentException(String.format("Team %s does not exist.", tokens[1]));
                        }
                        break;
                    case "Remove":
                        try {
                            if (!team.getName().equals(tokens[1])) {
                                throw new IllegalArgumentException(String.format("Team %s does not exist.", tokens[1]));
                            } else {
                                team.removePlayer(tokens[2]);
                            }
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                        }
                    {


                    }

                    break;
                    case "Rating":
                        if (team.getName().equals(tokens[1])) {
                            team.getRatting();
                        } else {
                            throw new IllegalArgumentException(String.format("Team %s does not exist.", tokens[1]));
                        }
                        break;
                }
                input = scanner.nextLine();
            }

            System.out.println(String.format("%s - %.0f", team.getName(), team.getRatting()));

        } catch (
                IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }
}
package barracksWars.interfaces;

import jdk.jshell.spi.ExecutionControl.NotImplementedException;

public interface Executable {

	String execute() throws NotImplementedException;

}

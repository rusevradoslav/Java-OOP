package logger_library.layouts.interfaces;

public interface Layout {

    String format(String date, String reportLevel, String message);

}

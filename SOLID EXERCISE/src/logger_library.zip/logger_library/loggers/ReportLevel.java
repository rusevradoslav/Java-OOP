package logger_library.loggers;

public enum ReportLevel {
        INFO ,
        WARNING ,
        ERROR ,
        CRITICAL ,
        FATAL
}
